﻿Public Class frmMain
    Private Sub ToolStrpMnuItmSaveAs_Click(sender As Object, e As EventArgs) Handles ToolStrpMnuItmSaveAs.Click
        Try
            Dim SaveFileDialog1 As New SaveFileDialog
            SaveFileDialog1.Title = "Save text file"
            SaveFileDialog1.Filter = "Text files|*.txt"
            If SaveFileDialog1.ShowDialog = DialogResult.OK Then
                IO.File.WriteAllText(SaveFileDialog1.FileName, txtMain.Text)

            End If
        Catch ex As Exception
            MsgBox("Could not save that file because the following error occurred:" & vbNewLine & ex.Message)
        End Try

    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ToolStrpMnuItmOpen.Click
        Try
            Dim SaveFileDialog1 As New OpenFileDialog
            SaveFileDialog1.Title = "Open text file"
            SaveFileDialog1.Filter = "Text files|*.txt"
            If SaveFileDialog1.ShowDialog = DialogResult.OK Then
                txtMain.Text = IO.File.ReadAllText(SaveFileDialog1.FileName)

            End If
        Catch ex As Exception
            MsgBox("Could not open that file because the following error occurred:" & vbNewLine & ex.Message)
        End Try

    End Sub

    Private Sub IToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ToolStrpMnuItmAbout.Click
        frmAbout.ShowDialog()
    End Sub


End Class
