﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.MnuStrpMain = New System.Windows.Forms.MenuStrip()
        Me.ToolStrpMnuItmSaveAs = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrpMnuItmOpen = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrpMnuItmAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.txtMain = New System.Windows.Forms.TextBox()
        Me.MnuStrpMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'MnuStrpMain
        '
        Me.MnuStrpMain.ImageScalingSize = New System.Drawing.Size(28, 28)
        Me.MnuStrpMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStrpMnuItmSaveAs, Me.ToolStrpMnuItmOpen, Me.ToolStrpMnuItmAbout})
        Me.MnuStrpMain.Location = New System.Drawing.Point(0, 0)
        Me.MnuStrpMain.Name = "MnuStrpMain"
        Me.MnuStrpMain.Size = New System.Drawing.Size(876, 58)
        Me.MnuStrpMain.TabIndex = 0
        Me.MnuStrpMain.Text = "MenuStrip1"
        '
        'ToolStrpMnuItmSaveAs
        '
        Me.ToolStrpMnuItmSaveAs.Name = "ToolStrpMnuItmSaveAs"
        Me.ToolStrpMnuItmSaveAs.Padding = New System.Windows.Forms.Padding(10)
        Me.ToolStrpMnuItmSaveAs.Size = New System.Drawing.Size(121, 54)
        Me.ToolStrpMnuItmSaveAs.Text = "Save as..."
        '
        'ToolStrpMnuItmOpen
        '
        Me.ToolStrpMnuItmOpen.Name = "ToolStrpMnuItmOpen"
        Me.ToolStrpMnuItmOpen.Padding = New System.Windows.Forms.Padding(10)
        Me.ToolStrpMnuItmOpen.Size = New System.Drawing.Size(103, 54)
        Me.ToolStrpMnuItmOpen.Text = "Open..."
        '
        'ToolStrpMnuItmAbout
        '
        Me.ToolStrpMnuItmAbout.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStrpMnuItmAbout.Name = "ToolStrpMnuItmAbout"
        Me.ToolStrpMnuItmAbout.Padding = New System.Windows.Forms.Padding(10)
        Me.ToolStrpMnuItmAbout.Size = New System.Drawing.Size(42, 54)
        Me.ToolStrpMnuItmAbout.Text = "i"
        '
        'txtMain
        '
        Me.txtMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtMain.Location = New System.Drawing.Point(0, 58)
        Me.txtMain.Multiline = True
        Me.txtMain.Name = "txtMain"
        Me.txtMain.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtMain.Size = New System.Drawing.Size(876, 478)
        Me.txtMain.TabIndex = 1
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(168.0!, 168.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.ClientSize = New System.Drawing.Size(876, 536)
        Me.Controls.Add(Me.txtMain)
        Me.Controls.Add(Me.MnuStrpMain)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(0, 29)
        Me.MainMenuStrip = Me.MnuStrpMain
        Me.Name = "frmMain"
        Me.Text = "Save/Load Text"
        Me.MnuStrpMain.ResumeLayout(False)
        Me.MnuStrpMain.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MnuStrpMain As MenuStrip
    Friend WithEvents ToolStrpMnuItmSaveAs As ToolStripMenuItem
    Friend WithEvents ToolStrpMnuItmOpen As ToolStripMenuItem
    Friend WithEvents txtMain As TextBox
    Friend WithEvents ToolStrpMnuItmAbout As ToolStripMenuItem
End Class
