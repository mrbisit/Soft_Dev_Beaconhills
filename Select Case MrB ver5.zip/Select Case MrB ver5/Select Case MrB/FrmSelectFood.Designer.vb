﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmSelectFood
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmSelectFood))
        Me.CBoxSelectFood = New System.Windows.Forms.ComboBox()
        Me.BtnDisplayOrder = New System.Windows.Forms.Button()
        Me.TxtFirstName = New System.Windows.Forms.TextBox()
        Me.TxtDisplaySelection = New System.Windows.Forms.TextBox()
        Me.TxtDisplayOrder = New System.Windows.Forms.TextBox()
        Me.LblName = New System.Windows.Forms.Label()
        Me.LblSelectFood = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.SaverAsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MrbToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DavidToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BtnAddToOrder = New System.Windows.Forms.Button()
        Me.BtnSaveOrder = New System.Windows.Forms.Button()
        Me.DGCustOrder = New System.Windows.Forms.DataGridView()
        Me.Item = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Description = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Amount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.DGCustOrder, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CBoxSelectFood
        '
        Me.CBoxSelectFood.FormattingEnabled = True
        Me.CBoxSelectFood.Items.AddRange(New Object() {"Pizza", "Burger", "Chips", "Pie"})
        Me.CBoxSelectFood.Location = New System.Drawing.Point(228, 164)
        Me.CBoxSelectFood.Name = "CBoxSelectFood"
        Me.CBoxSelectFood.Size = New System.Drawing.Size(232, 33)
        Me.CBoxSelectFood.TabIndex = 0
        Me.CBoxSelectFood.UseWaitCursor = True
        '
        'BtnDisplayOrder
        '
        Me.BtnDisplayOrder.Location = New System.Drawing.Point(255, 446)
        Me.BtnDisplayOrder.Name = "BtnDisplayOrder"
        Me.BtnDisplayOrder.Size = New System.Drawing.Size(181, 65)
        Me.BtnDisplayOrder.TabIndex = 2
        Me.BtnDisplayOrder.Text = "Display Order"
        Me.BtnDisplayOrder.UseVisualStyleBackColor = True
        Me.BtnDisplayOrder.UseWaitCursor = True
        '
        'TxtFirstName
        '
        Me.TxtFirstName.Location = New System.Drawing.Point(228, 80)
        Me.TxtFirstName.Name = "TxtFirstName"
        Me.TxtFirstName.Size = New System.Drawing.Size(232, 31)
        Me.TxtFirstName.TabIndex = 3
        Me.TxtFirstName.UseWaitCursor = True
        '
        'TxtDisplaySelection
        '
        Me.TxtDisplaySelection.Location = New System.Drawing.Point(228, 239)
        Me.TxtDisplaySelection.Name = "TxtDisplaySelection"
        Me.TxtDisplaySelection.Size = New System.Drawing.Size(232, 31)
        Me.TxtDisplaySelection.TabIndex = 4
        Me.TxtDisplaySelection.UseWaitCursor = True
        '
        'TxtDisplayOrder
        '
        Me.TxtDisplayOrder.Location = New System.Drawing.Point(213, 294)
        Me.TxtDisplayOrder.Multiline = True
        Me.TxtDisplayOrder.Name = "TxtDisplayOrder"
        Me.TxtDisplayOrder.Size = New System.Drawing.Size(249, 129)
        Me.TxtDisplayOrder.TabIndex = 5
        Me.TxtDisplayOrder.UseWaitCursor = True
        '
        'LblName
        '
        Me.LblName.AutoSize = True
        Me.LblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblName.Location = New System.Drawing.Point(118, 80)
        Me.LblName.Name = "LblName"
        Me.LblName.Size = New System.Drawing.Size(90, 31)
        Me.LblName.TabIndex = 7
        Me.LblName.Text = "Name"
        Me.LblName.UseWaitCursor = True
        '
        'LblSelectFood
        '
        Me.LblSelectFood.AutoSize = True
        Me.LblSelectFood.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblSelectFood.Location = New System.Drawing.Point(45, 166)
        Me.LblSelectFood.Name = "LblSelectFood"
        Me.LblSelectFood.Size = New System.Drawing.Size(170, 31)
        Me.LblSelectFood.TabIndex = 8
        Me.LblSelectFood.Text = "Select Food"
        Me.LblSelectFood.UseWaitCursor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1127, 40)
        Me.MenuStrip1.TabIndex = 9
        Me.MenuStrip1.Text = "MenuStrip1"
        Me.MenuStrip1.UseWaitCursor = True
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator1, Me.SaverAsToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(77, 36)
        Me.ToolStripMenuItem1.Text = "Save"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(193, 6)
        '
        'SaverAsToolStripMenuItem
        '
        Me.SaverAsToolStripMenuItem.Name = "SaverAsToolStripMenuItem"
        Me.SaverAsToolStripMenuItem.Size = New System.Drawing.Size(196, 38)
        Me.SaverAsToolStripMenuItem.Text = "Save As"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MrbToolStripMenuItem, Me.DavidToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(77, 36)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'MrbToolStripMenuItem
        '
        Me.MrbToolStripMenuItem.Name = "MrbToolStripMenuItem"
        Me.MrbToolStripMenuItem.Size = New System.Drawing.Size(175, 38)
        Me.MrbToolStripMenuItem.Text = "Mrb"
        '
        'DavidToolStripMenuItem
        '
        Me.DavidToolStripMenuItem.Name = "DavidToolStripMenuItem"
        Me.DavidToolStripMenuItem.Size = New System.Drawing.Size(175, 38)
        Me.DavidToolStripMenuItem.Text = "David"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(92, 36)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'BtnAddToOrder
        '
        Me.BtnAddToOrder.Location = New System.Drawing.Point(32, 294)
        Me.BtnAddToOrder.Name = "BtnAddToOrder"
        Me.BtnAddToOrder.Size = New System.Drawing.Size(175, 76)
        Me.BtnAddToOrder.TabIndex = 10
        Me.BtnAddToOrder.Text = "Add to Order"
        Me.BtnAddToOrder.UseVisualStyleBackColor = True
        Me.BtnAddToOrder.UseWaitCursor = True
        '
        'BtnSaveOrder
        '
        Me.BtnSaveOrder.Location = New System.Drawing.Point(36, 430)
        Me.BtnSaveOrder.Name = "BtnSaveOrder"
        Me.BtnSaveOrder.Size = New System.Drawing.Size(170, 80)
        Me.BtnSaveOrder.TabIndex = 11
        Me.BtnSaveOrder.Text = "Save Order"
        Me.BtnSaveOrder.UseVisualStyleBackColor = True
        Me.BtnSaveOrder.UseWaitCursor = True
        '
        'DGCustOrder
        '
        Me.DGCustOrder.AllowUserToOrderColumns = True
        Me.DGCustOrder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGCustOrder.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Item, Me.Description, Me.Amount})
        Me.DGCustOrder.Location = New System.Drawing.Point(521, 95)
        Me.DGCustOrder.Name = "DGCustOrder"
        Me.DGCustOrder.RowTemplate.Height = 33
        Me.DGCustOrder.Size = New System.Drawing.Size(568, 296)
        Me.DGCustOrder.TabIndex = 12
        Me.DGCustOrder.UseWaitCursor = True
        '
        'Item
        '
        Me.Item.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.Item.HeaderText = "Item #"
        Me.Item.Name = "Item"
        Me.Item.Width = 115
        '
        'Description
        '
        Me.Description.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.Description.HeaderText = "Description"
        Me.Description.Name = "Description"
        Me.Description.Width = 165
        '
        'Amount
        '
        Me.Amount.HeaderText = "Amount"
        Me.Amount.Name = "Amount"
        '
        'FrmSelectFood
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Select_Case_MrB.My.Resources.Resources.food
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1127, 591)
        Me.Controls.Add(Me.DGCustOrder)
        Me.Controls.Add(Me.BtnSaveOrder)
        Me.Controls.Add(Me.BtnAddToOrder)
        Me.Controls.Add(Me.LblSelectFood)
        Me.Controls.Add(Me.LblName)
        Me.Controls.Add(Me.TxtDisplayOrder)
        Me.Controls.Add(Me.TxtDisplaySelection)
        Me.Controls.Add(Me.TxtFirstName)
        Me.Controls.Add(Me.BtnDisplayOrder)
        Me.Controls.Add(Me.CBoxSelectFood)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "FrmSelectFood"
        Me.Text = "Select Food"
        Me.UseWaitCursor = True
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.DGCustOrder, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents CBoxSelectFood As ComboBox
    Friend WithEvents BtnDisplayOrder As Button
    Friend WithEvents TxtFirstName As TextBox
    Friend WithEvents TxtDisplaySelection As TextBox
    Friend WithEvents TxtDisplayOrder As TextBox
    Friend WithEvents LblName As Label
    Friend WithEvents LblSelectFood As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaverAsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MrbToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DavidToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BtnAddToOrder As Button
    Friend WithEvents BtnSaveOrder As Button
    Friend WithEvents DGCustOrder As DataGridView
    Friend WithEvents Item As DataGridViewTextBoxColumn
    Friend WithEvents Description As DataGridViewTextBoxColumn
    Friend WithEvents Amount As DataGridViewTextBoxColumn
End Class
