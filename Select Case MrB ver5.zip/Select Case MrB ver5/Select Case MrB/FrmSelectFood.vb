﻿

Public Class FrmSelectFood
    Dim exitVariable As Integer = 0
    Dim itemDescription As String
    Dim itemAmount As Decimal
    Dim orderTotalAmount As Decimal
    Dim rowIndex As Integer = 1
    Public Function ExitApp()
        Application.Exit()
        End
    End Function

    Private Sub CBoxSelectFood_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBoxSelectFood.SelectedIndexChanged
        TxtDisplaySelection.Text = CBoxSelectFood.Text
        'whatever option (food) is selected in the CBoxSelectFood 
        'will display the select case equivelent price of that burger
        'in TxtDisplaySelection textbox below the combobox
    End Sub



    Private Sub TxtFirstName_TextChanged(sender As Object, e As EventArgs) Handles TxtFirstName.TextChanged

        If TxtFirstName.Text = "" Then
            exitVariable = exitVariable + 1

            If exitVariable = 3 Then
                MsgBox("The application will now exit")
                Call ExitApp()
            End If
            MsgBox("Please enter your name " & "You have tried " & exitVariable & " times")
            TxtFirstName.Focus()
        End If

    End Sub

    Private Sub TxtBoxtotal_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub FrmSelectFood_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TxtDisplaySelection_TextChanged(sender As Object, e As EventArgs) Handles TxtDisplaySelection.TextChanged
        'Case and select combination to provide pricing for items from combo box
        Select Case CBoxSelectFood.Text
            Case "Pizza"
                itemDescription = "Pizza"
                itemAmount = 11.4
                TxtDisplaySelection.Text = itemDescription & " " & FormatCurrency(itemAmount, 2)
            Case "Burger"
                itemDescription = "Burger"
                itemAmount = 5.4
                TxtDisplaySelection.Text = itemDescription & " " & FormatCurrency(itemAmount, 2)
            Case "Chips"
                itemDescription = "Chips"
                itemAmount = 2.6
                TxtDisplaySelection.Text = itemDescription & " " & FormatCurrency(itemAmount, 2)
            Case "Pie"
                itemDescription = "Pie"
                itemAmount = 15
                TxtDisplaySelection.Text = itemDescription & " " & FormatCurrency(itemAmount, 2)
            Case Else
                MsgBox("Please select an item from the list")
        End Select

    End Sub

    Private Sub BtnDisplayOrder_Click(sender As Object, e As EventArgs) Handles BtnDisplayOrder.Click

        If CBoxSelectFood.Text = "" Then
            MsgBox("Please Select from Pizza List")
        End If
        ':)this code displays in TextBoxdisplayall.Text the content
        'of the above textboxes
        '& vbCrLf & This creates a new line, also known as a carriage return
        TxtDisplayOrder.Text = "Hi " & TxtFirstName.Text & vbCrLf &
                               "Number of items: " & (rowIndex - 1) & vbCrLf

        For Each foundFile As String In
My.Computer.FileSystem.GetFiles("C:\VB")
            'look at all files found in C:VB and list them in 
            'the OrderList.txt in the directory below
            'this allows you to view the orders submitted
            'the user is unaware of this
            foundFile = foundFile & vbCrLf
            My.Computer.FileSystem.WriteAllText _
            ("C:\CODING\OrderList.txt", foundFile, True)
        Next
    End Sub



    Private Sub TxtDisplayOrder_TextChanged(sender As Object, e As EventArgs) Handles TxtDisplayOrder.TextChanged

    End Sub

    Private Sub LblName_Click(sender As Object, e As EventArgs) Handles LblName.Click

    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click

    End Sub


    Private Sub SaveToolStripMenuItem_Click(sender As Object, e As EventArgs)


    End Sub

    Private Sub DirectoryToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        Dim filePath As String
        filePath = My.Computer.FileSystem.SpecialDirectories.CurrentUserApplicationData
        MsgBox(filePath)
        'Displays in a MessageBox the location of the VB project
    End Sub

    Private Sub ViewOrdersToolStripMenuItem_Click(sender As Object, e As EventArgs)


    End Sub

    Private Sub SaverAsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaverAsToolStripMenuItem.Click
        Dim SaveFile As New SaveFileDialog
        SaveFile.FileName = TxtFirstName.Text
        'Uses the name of the user as the name of the file to be saved
        ' You could also add the surname using - & TxtboxSurname.Text
        SaveFile.Filter = "Text Files (*.txt) |*.txt|file (*)|*|All Files (*.*)|*.*)"
        SaveFile.Title = "Send"
        SaveFile.ShowDialog()
        Try
            Dim write As New System.IO.StreamWriter(SaveFile.FileName)
            write.Write(TxtDisplayOrder.Text)
            'saves text in TxtDisplayOrder to a text file created by

            write.Close()
            MsgBox("File Saved")


        Catch ex As Exception

        End Try
        'Saves order with the name of file chosen by user'

        Dim SaveF As New System.IO.StreamWriter("C:\CODING\2017\List of Orders.txt")
        SaveF.Write(TxtDisplayOrder.Text)
        SaveF.Close()
        'this code automatically creates the text file List of Orders.txt in the bin folder of your app
        'and saves the last order in textbox in TxtDisplayOrder.Text it overrides the last order
    End Sub

    Private Sub LblSelectFood_Click(sender As Object, e As EventArgs) Handles LblSelectFood.Click

    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles BtnAddToOrder.Click
        DGCustOrder.Visible = True

        DGCustOrder.Rows.Add(rowIndex, itemDescription, FormatCurrency(itemAmount, 2))
        'MsgBox("Current Row Index: " & rowIndex)
        orderTotalAmount = orderTotalAmount + itemAmount
        rowIndex = rowIndex + 1
    End Sub
    Private Sub ResetVariables()
        'Resets all variables
        itemDescription = ""
        itemAmount = 0
        orderTotalAmount = 0
        rowIndex = 1

        'Resets User visible objects
        DGCustOrder.Rows.Clear()
        DGCustOrder.Visible = False
        TxtFirstName.Text = ""
        TxtDisplayOrder.Text = ""
        TxtDisplaySelection.Text = ""

        'Moves focus to FirstName Text Box
        TxtFirstName.Focus()

    End Sub

    Private Sub BtnSaveOrder_Click(sender As Object, e As EventArgs) Handles BtnSaveOrder.Click
        SaveOrder()             ' Calls the SaveOrder Sub to complete the order.
    End Sub
    'This function provides the ability to write all informaiton that is stored
    'in the data grid to a string. The string with the formatted order informaiton is returned 
    'to the calling function / sub / method
    Private Function WriteDG() As String
        WriteDG = ""
        For Each row As DataGridViewRow In DGCustOrder.Rows
            If Not row.IsNewRow Then
                WriteDG = WriteDG + (row.Cells(1).Value.ToString & "," & row.Cells(2).Value.ToString)
                WriteDG = WriteDG + vbCrLf
            End If
        Next
        'MsgBox("Valud of Container: " + WriteDG)
    End Function

    Private Sub SaveOrder()
        Dim TimeStamp As String                 'Creates a timestamp for the current order
        Dim SaveFile As New SaveFileDialog      'SaveFile Dialog box variable
        'Sets relevant properties for the SaveFile Dialog Box

        TimeStamp = DateAndTime.Now.ToString(" yyyy MM dd")

        With SaveFile
            .InitialDirectory = ("C:\VB\OrderList")
            .FileName = (TxtFirstName.Text + TimeStamp)
            .Filter = "Text File (*.txt)|*.txt|All Files (*.*)|*.*"
            .Title = "Send"
            .ShowDialog()
        End With

        'Creates file to drive for retrieval and use by the operator. 
        'Note that this action is not visible to the user of the application
        Try
            Dim write As New System.IO.StreamWriter(SaveFile.FileName)

            For Each row As DataGridViewRow In DGCustOrder.Rows
                If Not row.IsNewRow Then
                    With write
                        .Write(row.Cells(1).Value.ToString & "," & row.Cells(2).Value.ToString)
                        .Write(vbCrLf)
                    End With
                End If
            Next
            write.Close()
            MsgBox("Order submitted and File Saved")

        Catch ex As Exception

        End Try

        'The below code creates a List of Orders file for use by the Shop operator.
        'Information from customer orders are saved in a hard coded location
        Try
            'Dim SaveF As New System.IO.StreamWriter("C:\Temp\Chloe School\VB\List of Orders.txt")
            Dim SaveF = System.IO.File.CreateText("C:\MyApp\List of Orders.txt")
            With SaveF
                .Write("Order from: " + TxtFirstName.Text + " Placed on: " + TimeStamp + vbCrLf)
                .Write(WriteDG())
                .Write("End of order")
                .Write("-------------------------------------------------------------------")
                .Close()
            End With
        Catch ex As Exception

        End Try

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGCustOrder.CellContentClick

    End Sub
End Class
