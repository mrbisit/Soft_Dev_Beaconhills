﻿Public Class Login
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If txtUsername.Text = "log in" And txtPassword.Text = "password" Then
            MsgBox("Correct Password")
            FrmSelectFood.Visible = True
            'in the properties change the seeting to false
            Me.Visible = False
            'makes log in form invisible

        ElseIf txtUsername.Text = "IT" And txtPassword.Text = "Service" Then
            MsgBox("Correct Password")
            ITService.Visible = True
            Me.Visible = False
        Else
            MsgBox("Wrong Password")
            ITService.Visible = False
        End If

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class